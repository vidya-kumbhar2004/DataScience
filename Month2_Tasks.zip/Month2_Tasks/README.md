# Multi-Domain Data Analysis Portfolio

## Introduction

This repository presents a **complete data analysis portfolio consisting of five real-world projects** developed as part of **Month 2: Data Analysis & Visualization Expertise**.

The portfolio demonstrates practical skills in:

* Data cleaning and preprocessing
* Advanced pandas operations
* Statistical analysis
* Data visualization
* Business insight generation

Each project uses a different domain dataset and follows a structured, repeatable analysis workflow suitable for real business scenarios.

## Projects Included

### 1. Supermarket Sales Analysis (Retail)

**Goal:**
Analyze sales performance, customer behavior, and product trends.

**Key Focus Areas:**

* Product-wise revenue contribution
* Customer type comparison
* Daily sales trend analysis

**Outcome:**
Identified high-revenue products and customer segments to support better inventory and promotion planning.

### 2. Student Performance Analysis (Education)

**Goal:**
Evaluate academic performance and identify factors influencing student success.

**Key Focus Areas:**

* Pass and fail rate calculation
* Attendance impact on scores
* Subject-wise performance comparison

**Outcome:**
Confirmed strong correlation between attendance and academic performance and highlighted weak subjects requiring intervention.

### 3. Weather Data Analysis (Weather)

**Goal:**
Study temperature and rainfall patterns to identify seasonal trends.

**Key Focus Areas:**

* Temperature trend analysis
* Monthly rainfall distribution
* Seasonal variation detection

**Outcome:**
Clear seasonal patterns identified, useful for climate monitoring, agriculture planning, and infrastructure preparedness.

### 4. Stock Market Analysis (Finance)

**Goal:**
Analyze stock price movement and volatility for investment insights.

**Key Focus Areas:**

* Closing price trends
* Daily return analysis
* Volatility measurement

**Outcome:**
Detected high-volatility periods and trend changes that can support informed investment decisions.

### 5. House Price Analysis (Real Estate)

**Goal:**
Identify factors influencing house prices.

**Key Focus Areas:**

* Price distribution analysis
* Area vs price relationship
* Location-wise price comparison

**Outcome:**
Confirmed that property size and location are the strongest drivers of house prices.

## Repository Structure

```
├── README.md
├── requirements.txt
├── data/
│   ├── supermarket_sales.csv
│   ├── Student_Performance_Dataset.csv
│   ├── Weather Data.csv
│   ├── stock_prices.csv
│   └── house_prices.csv
├── notebooks/
│   ├── 01_Supermarket_Sales_Analysis.ipynb
│   ├── 02_Student_Performance_Analysis.ipynb
│   ├── 03_Weather_Data_Analysis.ipynb
│   ├── 04_Stock_Market_Analysis.ipynb
│   └── 05_House_Price_Analysis.ipynb
├── reports/
│   ├── 01_Supermarket_Sales_Report.pdf
│   ├── 02_Student_Performance_Report.pdf
│   ├── 03_Weather_Data_Report.pdf
│   ├── 04_Stock_Market_Report.pdf
│   └── 05_House_Price_Report.pdf
└── visualizations/
```
## Tools & Technologies

* Python
* pandas
* matplotlib
* Jupyter Notebook


## Skills Demonstrated

* Data cleaning and validation
* Statistical analysis (mean, median, correlation, trends)
* Data visualization best practices
* Insight-driven storytelling
* Business-oriented recommendations
* Professional documentation

## Deliverables Summary

* ✔ 5 complete Jupyter notebooks
* ✔ 5 professional PDF reports with executive summaries
* ✔ 15+ visualizations (3+ per project)
* ✔ Clean, organized GitHub structure

## How to Run

```bash

pip install -r requirements.txt
jupyter notebook
```
